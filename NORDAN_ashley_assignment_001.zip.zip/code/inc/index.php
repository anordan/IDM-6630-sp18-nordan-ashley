<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Home</title>
  </head>
  <link rel="stylesheet" href="../css/main.css">
  <body>
   <?php include "../inc/nav.php" ?>
  
    <?php echo "<h1>Wes Anderson</h1>"; ?>
	
	<img src="img/zebra-wallpaper.jpg" alt="zebra wallpaper">
	
  </body>
</html>
