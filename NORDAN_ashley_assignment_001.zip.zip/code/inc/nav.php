<ul>
<li><a href="../inc/index.php">Home</a></li>
<li><a href="../about/index.php">About</a></li>
<li><a href="../contact/index.php">Contact</a></li>
</ul>