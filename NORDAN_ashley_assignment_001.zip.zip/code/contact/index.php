<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Contact</title>
  </head>
   <link rel="stylesheet" href="../css/main.css">
  <body>
   <?php include "../inc/nav.php" ?>
   
    <?php echo "<h1>Contact Wes Anderson</h1>"; ?>
	
	<img src="img/brody-contact.jpg" alt="adrian brody on phone">
	<h2>Address:</h2> 
		<p>6, rue Arsene Houssaye, 75008, Paris.</p>  
	<h2>Tel.:</h2>
		<p>(33)(1)42899500</p>  
	<h2>Email:</h2>
		<p>wes.anderson@gmail.com</p>
	
	
  </body>
</html>
