<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>IDM 6630 20 Fall 2018</title>
  </head>
  <body>
    <?php echo "Ashley in the house"; ?>
  </body>
</html>
